#ifndef EXEC_H
#define EXEC_H

void exec(char **argv);

#endif // EXEC_H
